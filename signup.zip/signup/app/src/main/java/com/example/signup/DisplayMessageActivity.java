package com.example.signup;

import android.app.Activity;

public class DisplayMessageActivity extends Activity {
}
