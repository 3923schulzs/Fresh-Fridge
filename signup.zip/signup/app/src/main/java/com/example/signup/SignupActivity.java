//package com.example.signup;
//
//import android.os.Bundle;
//import android.view.View;
//import android.widget.EditText;
//import android.widget.Toast;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//public class SignupActivity extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_signup);
//    }
//
//    public void signUp(View view) {
//        // Implement the signup logic here
//        Toast.makeText(this, "Sign Up clicked", Toast.LENGTH_SHORT).show();
//    }
//
//    public void login(View view) {
//        // Implement the login logic here
//        Toast.makeText(this, "Login clicked", Toast.LENGTH_SHORT).show();
//    }
//
//    public void forgotPasswordClicked(View view) {
//        // Implement the forgot password logic here
//        Toast.makeText(this, "Forgot Password clicked", Toast.LENGTH_SHORT).show();
//    }
//}

package com.example.signup;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SignupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Find the buttons by their IDs
        Button signUpButton = findViewById(R.id.buttonSignUp);
        Button loginButton = findViewById(R.id.buttonLogin);

        // Set click listeners for the buttons
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(SignupActivity.this, "Sign Up clicked", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(SignupActivity.this, LoggedIn.class);
                intent.putExtra("message", "Welcome to LoggedIn!");
                startActivity(intent);
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(SignupActivity.this, "Login clicked", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(SignupActivity.this, SignedUp.class);
                intent.putExtra("message", "Hello from SignedUp!");
                startActivity(intent);
            }
        });

    }
}
