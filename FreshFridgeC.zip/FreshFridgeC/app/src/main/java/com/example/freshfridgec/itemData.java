package com.example.freshfridgec;

public class itemData{
    private String name;
    private String expDate;

    public itemData(String name, String expDate){
        this.name = name;
        this.expDate = expDate;
    }

    public String getItemName(){
        return name;
    }

    public String getexpDate(){
        return expDate;
    }
}
