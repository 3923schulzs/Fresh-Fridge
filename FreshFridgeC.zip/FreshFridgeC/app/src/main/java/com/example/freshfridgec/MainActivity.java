package com.example.freshfridgec;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.content.Intent;
import android.widget.Button;
import java.util.List;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView listView;
    private List<String> items;
    private ArrayAdapter<String> adapter;
    Button addition;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addition = findViewById(R.id.add);
        items = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        listView = findViewById(R.id.listview);
        listView.setAdapter(adapter);

        addition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int LAUNCHSecond = 1;
                Intent intent = new Intent(MainActivity.this, AddItemPage.class);
                startActivityForResult(intent, ADD_ITEM_REQUEST);
            }
        });


    }
    public void goAddItem(String item, String exp){
        String complete = item + "                    Will expire on: " + exp;
        items.add(complete);
        adapter.notifyDataSetChanged();
    }
    private static final int ADD_ITEM_REQUEST = 1;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_ITEM_REQUEST && resultCode == RESULT_OK) {
               String namefood = data.getStringExtra("NAME");
               String expfood = data.getStringExtra("EXP");
               goAddItem(namefood, expfood);
        }
    }
}